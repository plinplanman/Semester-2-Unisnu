class Data {
  dynamic data;
}

void main() {
  var data = Data();
  data.data = "ferdiansyah";
  print(data.data);
}
