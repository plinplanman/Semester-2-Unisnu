void main() {
  //boolean

  bool salah = false;
  print(salah);

  bool benar = true;
  print(benar);

  var kebenaran = 10;
  print(kebenaran < 9);
  print(kebenaran > 9);
}
