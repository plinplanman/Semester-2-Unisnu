void main() {
  print('hallo Indonesia');
  print('selamat pagi Indonesia');
  print('Jaya Indonesia');
}
