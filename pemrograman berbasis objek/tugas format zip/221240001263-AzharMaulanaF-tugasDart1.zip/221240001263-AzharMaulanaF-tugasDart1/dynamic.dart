void main() {
  dynamic variabel = 1000;
  print(variabel);
  variabel = true;
  print(variabel);

  variabel = 'Ferdi';
  print(variabel);
}
