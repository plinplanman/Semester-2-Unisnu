void main() {
  //number integer atau double
  int angka1 = 1;
  double angka2 = 2.5;
  print(angka1);
  print(angka2);
//num
  num angka = 10;
  print(angka);
  angka = 70;
  print(angka);
}
