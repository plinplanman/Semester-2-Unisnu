void hallo() {
  print('Hallo!! ');
  print('bang Messi');
}

void main() {
  hallo();
  hallo();
  hallo();
  hallo();
}
