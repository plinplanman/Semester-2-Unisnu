void main() {
  //hanya bisa diakses didalam function
  void hallo() {
    print('hallo inner function');
  }

  hallo();
  hallo();
}
