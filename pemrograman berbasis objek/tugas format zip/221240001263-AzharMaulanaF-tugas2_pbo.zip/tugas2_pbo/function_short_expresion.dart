int tambah(int pertama, int kedua) => pertama + kedua;

void main() {
  print(tambah(99, 1));
  print(tambah(98, 2));
}
