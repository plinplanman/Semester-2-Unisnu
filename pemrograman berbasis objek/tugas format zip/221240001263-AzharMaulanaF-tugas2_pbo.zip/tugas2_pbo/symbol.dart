void main() {
  Symbol nama1 = Symbol('ferdiasnyah');
  var nama2 = #latihan_dart;

  print(nama1);
  print(nama2);
}
