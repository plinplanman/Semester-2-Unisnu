void main() {
  var nama = <String>['azhar ', 'maulana', 'ferdiansyah'];
  for (var nilai in nama) {
    print(nilai);
  }

  //set
  var namaset = <String>['azhar ', 'maulana', 'ferdiansyah'];
  for (var nilai in namaset) {
    print(nilai);
  }
}
