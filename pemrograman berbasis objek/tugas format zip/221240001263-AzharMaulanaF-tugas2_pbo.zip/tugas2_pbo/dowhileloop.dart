void main() {
  var ulang = 20;
  do {
    print('perulangan ke $ulang');
    ulang++;
  } while (ulang <= 10);
}
