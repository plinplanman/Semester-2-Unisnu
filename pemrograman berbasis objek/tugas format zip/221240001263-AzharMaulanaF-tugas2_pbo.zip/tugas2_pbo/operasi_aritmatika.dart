void main() {
  var nilai1 = 10;
  var nilai2 = 2;
  print(nilai1 + nilai2);
  print(nilai1 - nilai2);
  print(nilai1 * nilai2);
  print(nilai1 / nilai2);
  print(nilai1 ~/ nilai2);
  print(nilai1 % nilai2);
}
