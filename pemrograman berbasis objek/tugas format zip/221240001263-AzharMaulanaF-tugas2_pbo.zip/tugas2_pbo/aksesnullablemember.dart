void main() {
  int? datainteger;
  double? datadouble = datainteger?.toDouble();
  print(datadouble);
}
