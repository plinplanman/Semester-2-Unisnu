void main() {
  //ditambah lambang tanya agar variabel bisa dikosongi
  int angka1 = 1;
  int? angka2;
  //print(angka1);
  print(angka2);
}
