void main() {
  var nilai = 80;
  var tugas = 60;
  if (nilai >= 90 && tugas >= 90) {
    print('nilai kamu A');
  } else if (nilai >= 80 && tugas >= 80) {
    print('nilai kamu b');
  } else if (nilai >= 70 && tugas >= 70) {
    print('nilai kamu c');
  } else {
    print('nilai kamu D');
  }
}
