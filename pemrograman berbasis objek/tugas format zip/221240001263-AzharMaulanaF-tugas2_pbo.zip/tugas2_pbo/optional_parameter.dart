void hallo(String namaawal, [String? namatengah, String? namaakhir]) {
  print('hallo $namaawal $namatengah $namaakhir');
}

void main() {
  hallo('windah', 'batubara', 'youtube');
  hallo('roger', 'sumatera');
  hallo('reza');
}
