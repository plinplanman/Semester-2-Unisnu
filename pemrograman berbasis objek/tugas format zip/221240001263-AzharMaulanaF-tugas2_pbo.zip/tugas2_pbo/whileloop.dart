void main() {
  var angka = 7;
  while (angka <= 10) {
    print('perulangan ke - $angka');
    angka++;
  }
}
