void main() {
  var nilai = 0;
  void increment() {
    print('increment');
    nilai++;
  }

  print(nilai);
  increment();
  increment();
  print(nilai);
}
