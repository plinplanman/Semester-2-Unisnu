void main() {
  var nama = ' azhar';

  void hallo() {
    var hello = 'hello $nama';
    print(hello);
  }

  hallo();
  //print(hallo);
}
