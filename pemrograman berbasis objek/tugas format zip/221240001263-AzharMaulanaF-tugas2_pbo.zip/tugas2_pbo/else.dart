void main() {
  var nilai = 80;
  var tugas = 60;
  if (nilai >= 75 && tugas >= 75) {
    print('kamu lulus');
  } else {
    print('kamu tidak lulus');
  }
}
