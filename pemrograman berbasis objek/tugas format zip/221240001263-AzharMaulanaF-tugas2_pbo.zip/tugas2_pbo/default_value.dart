void main() {
  String? tamu;

  String namatamu = tamu ?? 'tamu';
  print(namatamu);
}
