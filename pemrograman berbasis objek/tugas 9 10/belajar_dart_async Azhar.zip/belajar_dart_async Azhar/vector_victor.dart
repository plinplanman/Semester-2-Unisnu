import 'package:vector_victor/vector_victor.dart' as vector_victor;

void main(List<String> arguments) {
  print('Hello world: ${vector_victor.calculate()}!');
}
