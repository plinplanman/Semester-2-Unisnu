import 'data/multimedia.dart';

void main() {
  var video = Video();
  video.nama = "Belajar Dart";
  video.play();
  video.stop();
}
