import 'data/animal.dart';

void main() {
  var cat = Cat();
  cat.nama = 'SAPI';
  cat.run();
}
