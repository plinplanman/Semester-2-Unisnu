import 'data/category.dart';

void main() {
  var category = Category('1', 'Mobil');
  print(category.id);
  print(category.nama);
}
