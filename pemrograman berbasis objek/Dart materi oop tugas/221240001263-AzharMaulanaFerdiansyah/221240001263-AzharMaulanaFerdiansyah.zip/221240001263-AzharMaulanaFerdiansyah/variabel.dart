void main() {
  //tanpa variabel
  print('azhar maulana f (tanpa variabel)');

  //kode dengan variabel
  String nama;
  nama = 'Azhar Maulana F';

  print(nama);
  print(nama);

  //deklarasi variabel langsung
  String namasaya = 'nama saya FERDI';
  print(namasaya);

  //dengan var
  var name = 'AZHAR MAULANA FERDIANSYAH';
  print(name);

  //kata kunci final
  var namaawal = 'Maulana';
  final namaakhir = 'Ferdiansyah';
  print(namaawal);
  print(namaakhir);
  namaawal = 'Azhar';
  print(namaawal);
  print(namaakhir);

  //const
  final arraysatu = [1, 3, 5, 7, 9];
  const arraydua = [2, 4, 6, 8, 10];
  print(arraysatu);
  print(arraydua);

  //number integer atau double
  int angka1 = 1;
  double angka2 = 2.5;
  print(angka1);
  print(angka2);
//num
  num angka = 10;
  print(angka);
  angka = 70;
  print(angka);

  //boolean
  var kebenaran = 10;
  print(kebenaran < 9);
  print(kebenaran > 9);
}
