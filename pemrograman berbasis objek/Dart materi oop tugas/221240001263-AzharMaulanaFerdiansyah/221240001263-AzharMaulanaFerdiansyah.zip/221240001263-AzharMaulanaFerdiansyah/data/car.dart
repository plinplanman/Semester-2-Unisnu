class Car {
  String nama = '';

  void drive() {}

  int getTier() {
    return 0;
  }
}
