class Math {
  static int sum(int first, int second) => first + second;
}

void main() {
  print(Math.sum(1, 9));
  print(Math.sum(68, 1));
}
