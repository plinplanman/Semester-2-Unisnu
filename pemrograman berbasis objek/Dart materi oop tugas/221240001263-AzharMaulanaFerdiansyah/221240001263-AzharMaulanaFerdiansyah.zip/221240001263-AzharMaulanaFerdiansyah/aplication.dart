class Application {
  static String nama = 'Belajar Dart OOP';
  static String author = 'Azhar Maulana Ferdiansyah';
}

void main() {
  print(Application.nama);
  print(Application.author);
}
