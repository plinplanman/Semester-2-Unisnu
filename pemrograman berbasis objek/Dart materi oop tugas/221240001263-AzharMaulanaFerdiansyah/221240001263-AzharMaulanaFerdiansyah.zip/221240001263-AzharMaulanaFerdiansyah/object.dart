class Person {}

void main() {
  var number = 100;
  print(number.toString());

  var person = Person();
  print(person.toString());
}
