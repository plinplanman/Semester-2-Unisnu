import 'data/sum.dart';

void main() {
  var jumlah = Jumlah(20, 10);
  print(jumlah());

  var total = Total(10, 20);
  print(total());
}
